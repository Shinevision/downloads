Add You Mod To the shapesets.json in the "mod" folder like this:

"YOURMOD.json",

DONT TOUCH THE "NoMods" FOLDER 

When Your Done Put This In The Scrap Mechanic Folder

And Your Done!

*Don't use the .exe out of the folder make a shortcut!*
   _______      __
  / ____\ \    / /
 | (___  \ \  / / 
  \___ \  \ \/ /  
  ____) |  \  /   
 |_____/    \/    
01010011 01010110
